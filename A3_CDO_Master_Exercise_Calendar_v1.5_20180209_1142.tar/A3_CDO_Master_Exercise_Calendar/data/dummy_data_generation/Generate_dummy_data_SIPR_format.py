'''
##############################################################################
#
# FILE: Generate_dummy_data.py
#
#
# DESCRIPTION: Mock up some dummy CPS/JTIMS data 
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20171117     James Stockton     Initial Coding
# 20171120     James Stockton     tidy up and add JTIMS dummy data
# 20171213     James Stockton     hand jam a few long duration deployments
# 20171220     James Stockton     reworked to include deployments, natively
# 20171220     James Stockton     added Qty_max dictionary and field
# 20171221     James Stockton     reworked MAJCOM/Wings to mostly match reality
# 20180206     James Stockton     changed headers to match SIPR data formats
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

from os.path import dirname, realpath
import pandas as pd
import numpy as np
from datetime import datetime

# Hardcoded data path allows Spyder to run (helpful during development)
# development machine, data path
dirpath = "/home/stocktonjc/Coding/A3_CDO_Master_Exercise_Calendar/"
datapath = dirpath + "data/dummy_data_generation/"
# AWS server, data path
#datapath = "/home/stocktonjc/A3_CDO_Master_Exercise_Calendar/data/"

# Dynamically retrieve directory and build data path (used on server or 
# on dev. machine when testing "cl> bokeh serve")
#my_directory = dirname(realpath(__file__))
#datapath = my_directory + "/"

# define the output filename
outputFilename_CPS = "Dummy_CPS_Data.csv"
outputFilename_JTIMS = "Dummy_JTIMS_Data.csv"

# choose the number of entries to create
record_count = 140

# choose the starting date of the dummy data
starting_date = pd.to_datetime("2017-01-01")

##############################################################################

#%%

##############################################################################
# define event names, squadrons, associated locations, etc.
##############################################################################


# create list of fake Squadrons
squadron_list = ["Red FS",
                 "Gold FS",
                 "510 FS",
                 "555 FS",
                 "43 FS",
                 "95 FS",
                 "28 BS",
                 "9 BS",
                 "23 BS",
                 "69 BS",
                 "43 ECS",
                 "38 RS",
                 "12 ACCS",
                 "16 ACCS",
                 "12 RS",
                 "348 RS"
                 ]


# associate each squadron with an MDS
squadron_MDS_dictionary = {"Red FS":"X-Wing",
                           "Gold FS":"Y-Wing",
                           "510 FS":"F-16",
                           "555 FS":"F-16",
                           "43 FS":"F-22",
                           "95 FS":"F-22",
                           "28 BS":"B-1",
                           "9 BS":"B-1",
                           "23 BS":"B-52H",
                           "69 BS":"B-52H",
                           "43 ECS":"EC-130H",
                           "38 RS":"RC-135",
                           "12 ACCS":"E-8",
                           "16 ACCS":"E-8",
                           "12 RS":"RQ-4",
                           "348 RS":"RQ-4"
                           }

planes_per_fighter_squadron = 24
planes_per_bomber_squadron = 12
planes_per_other_squadron = 12

squadron_max_Qty_dictionary = {"Red FS":planes_per_fighter_squadron,
                               "Gold FS":planes_per_fighter_squadron,
                               "510 FS":planes_per_fighter_squadron,
                               "555 FS":planes_per_fighter_squadron,
                               "43 FS":planes_per_fighter_squadron,
                               "95 FS":planes_per_fighter_squadron,
                               "28 BS":planes_per_bomber_squadron,
                               "9 BS":planes_per_bomber_squadron,
                               "23 BS":planes_per_bomber_squadron,
                               "69 BS":planes_per_bomber_squadron,
                               "43 ECS":planes_per_other_squadron,
                               "38 RS":planes_per_other_squadron,
                               "12 ACCS":planes_per_other_squadron,
                               "16 ACCS":planes_per_other_squadron,
                               "12 RS":planes_per_other_squadron,
                               "348 RS":planes_per_other_squadron
                               }


Wing_list = ["Rebel FW","31 FW","325 FW","7 BW",
             "5 BW","55 WG","461 ACW","9 RW"]
# associate each squadron with a Wing
squadron_wing_dictionary = {"Red FS":Wing_list[0],
                            "Gold FS":Wing_list[0],
                            "510 FS":Wing_list[1],
                            "555 FS":Wing_list[1],
                            "43 FS":Wing_list[2],
                            "95 FS":Wing_list[2],
                            "28 BS":Wing_list[3],
                            "9 BS":Wing_list[3],
                            "23 BS":Wing_list[4],
                            "69 BS":Wing_list[4],
                            "43 ECS":Wing_list[5],
                            "38 RS":Wing_list[5],
                            "12 ACCS":Wing_list[6],
                            "16 ACCS":Wing_list[6],
                            "12 RS":Wing_list[7],
                            "348 RS":Wing_list[7]
                            }

NAF_list = ["3 AF","9 AF","8 AF","25 AF"]
# associate each squadron with a numbered AF
squadron_NAF_dictionary = {"Red FS":NAF_list[0],
                 "Gold FS":NAF_list[0],
                 "510 FS":NAF_list[0],
                 "555 FS":NAF_list[0],
                 "43 FS":NAF_list[1],
                 "95 FS":NAF_list[1],
                 "28 BS":NAF_list[2],
                 "9 BS":NAF_list[2],
                 "23 BS":NAF_list[2],
                 "69 BS":NAF_list[2],
                 "43 ECS":NAF_list[3],
                 "38 RS":NAF_list[3],
                 "12 ACCS":NAF_list[1],
                 "16 ACCS":NAF_list[1],
                 "12 RS":NAF_list[3],
                 "348 RS":NAF_list[3]
                 }
    
    
MAJCOM_list = ["USAFE","ACC","AFGSC"]
# associate each squadron with a MAJCOM
squadron_MAJCOM_dictionary = {"Red FS":MAJCOM_list[0],
                              "Gold FS":MAJCOM_list[0],
                              "510 FS":MAJCOM_list[0],
                              "555 FS":MAJCOM_list[0],
                              "43 FS":MAJCOM_list[1],
                              "95 FS":MAJCOM_list[1],
                              "28 BS":MAJCOM_list[2],
                              "9 BS":MAJCOM_list[2],
                              "23 BS":MAJCOM_list[2],
                              "69 BS":MAJCOM_list[2],
                              "43 ECS":MAJCOM_list[1],
                              "38 RS":MAJCOM_list[1],
                              "12 ACCS":MAJCOM_list[1],
                              "16 ACCS":MAJCOM_list[1],
                              "12 RS":MAJCOM_list[1],
                              "348 RS":MAJCOM_list[1]
                              }


# associate each squadron with a homebase
squadron_homebase_dictionary = {"Red FS":"Hoth AFB",
                                "Gold FS":"Hoth AFB",
                                "510 FS":"Aviano AFB",
                                "555 FS":"Aviano AFB",
                                "43 FS":"Tyndall AFB",
                                "95 FS":"Tyndall AFB",
                                "28 BS":"Dyess AFB",
                                "9 BS":"Dyess AFB",
                                "23 BS":"Minot AFB",
                                "69 BS":"Minot AFB",
                                "43 ECS":"Davis-Monthan AFB",
                                "38 RS":"Offutt AFB",
                                "12 ACCS":"Robins AFB",
                                "16 ACCS":"Robins AFB",
                                "12 RS":"Beale AFB",
                                "348 RS":"Grand Forks AFB"
                                }


CPS_event_name_list = ["ORANGE FLAG","BOTHAN FURY","EWOK THUNDER",
                       "TROPIC THUNDER","SYTHETIC FLAG",
                       "BOLD YODA","SCRUFFY NURF HERDER","FROZEN TAUNTAUN",
                       "SNOW SPEEDER","STAR DESTROYER",
                       "DOWNRANGE-A","DOWNRANGE-B"]

event_location_dictionary = {"ORANGE FLAG":"AFB able",
                             "BOTHAN FURY":"AFB baker",
                             "EWOK THUNDER":"AFB charlie",
                             "TROPIC THUNDER":"AFB dog",
                             "SYTHETIC FLAG":"AFB able",
                             "BOLD YODA":"AFB baker",
                             "SCRUFFY NURF HERDER":"AFB charlie",
                             "FROZEN TAUNTAUN":"AFB dog",
                             "SNOW SPEEDER":"AFB able",
                             "STAR DESTROYER":"AFB baker",
                             "DOWNRANGE-A":"Endor",
                             "DOWNRANGE-B":"Yavin-4"
                             }

MsnArea_list = ["Maritime","DCA","OCA AIR","OCONUS"]

event_msnarea_dictionary = {"ORANGE FLAG":MsnArea_list[0],
                             "BOTHAN FURY":MsnArea_list[1],
                             "EWOK THUNDER":MsnArea_list[2],
                             "TROPIC THUNDER":MsnArea_list[0],
                             "SYTHETIC FLAG":MsnArea_list[1],
                             "BOLD YODA":MsnArea_list[2],
                             "SCRUFFY NURF HERDER":MsnArea_list[0],
                             "FROZEN TAUNTAUN":MsnArea_list[1],
                             "SNOW SPEEDER":MsnArea_list[2],
                             "STAR DESTROYER":MsnArea_list[0],
                             "DOWNRANGE-A":MsnArea_list[3],
                             "DOWNRANGE-B":MsnArea_list[3]
                             }

eventType_list = ["EXERCISES-FLAG","EXERCISES_OTHER","DEPLOYMENT"]
event_eventType_dictionary = {"ORANGE FLAG":eventType_list[0],
                              "BOTHAN FURY":eventType_list[1],
                              "EWOK THUNDER":eventType_list[1],
                              "TROPIC THUNDER":eventType_list[0],
                              "SYTHETIC FLAG":eventType_list[0],
                              "BOLD YODA":eventType_list[1],
                              "SCRUFFY NURF HERDER":eventType_list[1],
                              "FROZEN TAUNTAUN":eventType_list[1],
                              "SNOW SPEEDER":eventType_list[1],
                              "STAR DESTROYER":eventType_list[1],
                              "DOWNRANGE-A":eventType_list[2],
                              "DOWNRANGE-B":eventType_list[2]
                             }

##############################################################################

#%%

##############################################################################
# Build up event records using the above dictionaries, random dates, etc.
##############################################################################

# define the list of columns as pulled from a CPS screenshot (Qty_max added)
CPS_column_list = ["Class",
                   "Event",
                   "Event #",
                   "Location",
                   "Start",
                   "End",
                   "Qty",
                   "Qty_max",
                   "MDS",
                   "Msn Area",
                   "NAF",
                   "MAJCOM",
                   "Wing",
                   "Sqdn",
                   "Homebase",
                   "Event Type",
                   "FTN",
#                   "Note",
                   "AsgnID"]

# prepare empty lists for each data column. data will be iteratively appended
CPS_Class_data = []
CPS_Event_data = []
CPS_EventNum_data = []
CPS_Location_data = []
CPS_Start_data = []
CPS_End_data = []
CPS_Qty_data = []
CPS_Qty_max_data = []
CPS_MDS_data = []
CPS_Msn_Area_data = []
CPS_NAF_data = []
CPS_MAJCOM_data = []
CPS_Wing_data = []
CPS_Sqdn_data =  []
CPS_Homebase_data = []
CPS_Event_Type_data = []
CPS_FTN_data = []
#CPS_Note_data = []
CPS_AsgnID_data = []


for ii in range(record_count):
  
  # assign a classification to the event (U for all)
  CPS_Class_data.append("(U)")
  
  # pick a random event from the list
  CPS_Event_data.append(CPS_event_name_list[np.random.randint(
                                                    len(CPS_event_name_list))])

  # pick a random squadron to associate with the event
  Sqdn = squadron_list[np.random.randint(len(squadron_list))]
  CPS_Sqdn_data.append(Sqdn)  

  # pick a random number for the number of assigned airframes
  # assumes planes_per_squadron is even, then ensures rand_pick is a 
  # multiple of 2
  current_Qty = 2 * np.random.randint(1, squadron_max_Qty_dictionary[Sqdn]/2)
  CPS_Qty_data.append(current_Qty)
  
  # use the dictionaries to fill out the other fields given the event/squadron
  CPS_Location_data.append(event_location_dictionary[CPS_Event_data[ii]])
  CPS_Msn_Area_data.append(event_msnarea_dictionary[CPS_Event_data[ii]])  
  CPS_Event_Type_data.append(event_eventType_dictionary[CPS_Event_data[ii]])
  CPS_AsgnID_data.append(ii)
#  CPS_Note_data.append("notes, extra information")
  CPS_FTN_data.append("")
  CPS_Qty_max_data.append(squadron_max_Qty_dictionary[Sqdn])
  CPS_NAF_data.append(squadron_NAF_dictionary[CPS_Sqdn_data[ii]])
  CPS_MAJCOM_data.append(squadron_MAJCOM_dictionary[CPS_Sqdn_data[ii]])
  CPS_Wing_data.append(squadron_wing_dictionary[CPS_Sqdn_data[ii]])
  CPS_Homebase_data.append(squadron_homebase_dictionary[CPS_Sqdn_data[ii]]) 
  CPS_MDS_data.append(squadron_MDS_dictionary[CPS_Sqdn_data[ii]])
  

# build the dataframe from the constructed columns
# columns 1,3,4 will be filled in after this step
CPS_data = pd.DataFrame(data = {CPS_column_list[0]:CPS_Class_data, 
                                CPS_column_list[1]:CPS_Event_data, 
                                CPS_column_list[3]:CPS_Location_data,
                                CPS_column_list[6]:CPS_Qty_data,
                                CPS_column_list[7]:CPS_Qty_max_data,
                                CPS_column_list[8]:CPS_MDS_data,
                                CPS_column_list[9]:CPS_Msn_Area_data,
                                CPS_column_list[10]:CPS_NAF_data,
                                CPS_column_list[11]:CPS_MAJCOM_data,
                                CPS_column_list[12]:CPS_Wing_data,
                                CPS_column_list[13]:CPS_Sqdn_data, 
                                CPS_column_list[14]:CPS_Homebase_data,
                                CPS_column_list[15]:CPS_Event_Type_data,
                                CPS_column_list[16]:CPS_FTN_data,
#                                CPS_column_list[17]:CPS_Note_data,
                                CPS_column_list[17]:CPS_AsgnID_data, 
                                },
                        columns = CPS_column_list)


# fill in data for the first record

# sort the dataframe by event name then squadron to facilitate event numbering
CPS_data.sort_values(['Event','Sqdn'], inplace = True)

# set the first event counter to 1
CPS_data['Event #'].iloc[0] = 1

# set the first start date within X days of the start of the period
CPS_data['Start'].iloc[0] = starting_date + \
                        pd.to_timedelta(np.random.randint(60,180),unit='D')       

# set the first end date within 2-3 weeks of the start date unless it's a 
# deployment. Then, set it to 90 days
if CPS_data['Msn Area'].iloc[0] != "OCONUS": 
  CPS_data['End'].iloc[0]  = CPS_data['Start'].iloc[0] + \
                             pd.to_timedelta(np.random.randint(14,21),unit='D')
else:
  CPS_data['End'].iloc[0] = CPS_data['Start'].iloc[0] + \
                                                   pd.to_timedelta(90,unit='D')


# fill in the remaining data by looping through rows starting with the second
for ii in range(1,record_count):
  
  # check if current event name is the same as the previous event name
  if CPS_data['Event'].iloc[ii] == CPS_data['Event'].iloc[ii-1]:
    # check if same squadron (if so then call it a new/different event number)
    if CPS_data['Sqdn'].iloc[ii] == CPS_data['Sqdn'].iloc[ii-1]:
      
      # set the new start date after the previous end date
      CPS_data['Start'].iloc[ii] = CPS_data['End'].iloc[ii-1] + \
                            pd.to_timedelta(np.random.randint(60,180),unit='D')   
      
      # if not a deployment set length to 14-21 days, else set to 90 days 
      if CPS_data['Msn Area'].iloc[ii] != "OCONUS": 
         CPS_data['End'].iloc[ii]  = CPS_data['Start'].iloc[ii] + \
                             pd.to_timedelta(np.random.randint(14,21),unit='D')
      else:
         CPS_data['End'].iloc[ii] = CPS_data['Start'].iloc[ii] + \
                                                   pd.to_timedelta(90,unit='D')
     
      # check if new start date has the same calendar year. If so, increment
      # event number, otherwise set to one b/c it's the first of that year
      if pd.to_datetime(CPS_data['Start'].iloc[ii]).year == \
                             pd.to_datetime(CPS_data['Start'].iloc[ii-1]).year:  
        CPS_data['Event #'].iloc[ii] = CPS_data['Event #'].iloc[ii-1] + 1
      else:     
        CPS_data['Event #'].iloc[ii] = 1               
               
    # if same event name, but different Sqdn, then copy info from prior row
    else:
      CPS_data['Event #'].iloc[ii] = CPS_data['Event #'].iloc[ii-1]
      CPS_data['Start'].iloc[ii] = CPS_data['Start'].iloc[ii-1] 
      CPS_data['End'].iloc[ii]  = CPS_data['End'].iloc[ii-1]

  # if landing here, we've hit a new event name; set it to one and continue
  else:
    CPS_data['Event #'].iloc[ii] = 1  
    CPS_data['Start'].iloc[ii] = starting_date + \
                            pd.to_timedelta(np.random.randint(60,180),unit='D')
                        
    # if not a deployment set length to 14-21 days, else set to 90 days     
    if CPS_data['Msn Area'].iloc[ii] != "OCONUS": 
      CPS_data['End'].iloc[ii] = CPS_data['Start'].iloc[ii] + \
                             pd.to_timedelta(np.random.randint(14,21),unit='D')
    else:    
      CPS_data['End'].iloc[ii]  = CPS_data['Start'].iloc[ii] + \
                                                   pd.to_timedelta(90,unit='D')      


# construct the event number in the correct format
CPS_data['Year'] = [x.strftime('%y') for x in CPS_data['Start']]

CPS_data['str_num'] = None

for ii in range(len(CPS_data['Event'])):
  if len(str(CPS_data['Event #'].iloc[ii])) > 1:
    CPS_data['str_num'].iloc[ii] = str(CPS_data['Event #'].iloc[ii])
  else:
    CPS_data['str_num'].iloc[ii] = "0" + str(CPS_data['Event #'].iloc[ii])
                                     
CPS_data['Event #'] = CPS_data['Year'] + "-" + CPS_data['str_num']  
         
CPS_data.drop(['Year','str_num'], axis = 1, inplace = True)

#############################################################################

#%%

##############################################################################
# Build JTIMS records from fake CPS data constructed above
##############################################################################
                   
# The JTIMS data (SIPR) that we found an ~easy way to get has an obnoxious
# format. It's a multindex header with an empty field as the first entry
# of the highest index level. So to mimic that format here, I'm building the
# lists to create the multiindex and writing it out to match in csv.

row_one = ["","","","","","","","","","","","","","","","","","","","","","",
           "","","","","","","","","","","","","","","","","","",
           "Airlift","","","","","","","","","","",
           "Sealift","","","","","","","","","",
           "Ground/Surface","","","","","","","","",
           "Milestones","","","","","",
           "JELC Milestones","","","","","","","",
           "Expenses","","","","",
           "US DoD UIC Requested (Unfilled)","","","","","","","","","","","",
           "","","","","","",
           "US DoD UIC Sourced (Filled)","","","","","","","","","","","","",
           "","","","","","",
           "US DoD Exercise SME (Individual) Requirements (Unfilled)","","",
           "","","","","","","","","","","","","","","","","",
           "US DoD Exercise SME (Individual) Requirements (Filled)","","","",
           "","","","","","","","","","","","",
           "US Gov't Rquested (Unfilled)","","","","","","","","","","","","",
           "","","",
           "US Gov't Sourced (Filled)","","","","","","","","","","","","",
           "Coalition","","","","","","","","","",
           "NGO/PVO/IO","","","","","","","",
           "Live Ranges/Sites","","","","","",
           "Live Simulation Technologies","","","",
           "Virtual Simulation Technologies","","","",
           "Constructive Simulation Technologies","","",""]

row_two = ["Overall Event Classification","Event","Source",
           "Cancellation Reason","Employment Dates-Classification",
           "Employment Dates-Start Date","Employment Dates-End Date",
           "Inclusive Dates-Classification","Inclusive Dates-Start Date",
           "Inclusive Dates-End Date","Critical Cancellation Date",
           "Is Stratlift Required?","Command Priority","GEF Category",
           "GEF Subcategory","Outline the Benefits","Short Description",
           "Purpose","Scenario Description","Impact if Cancelled",
           "SMEB Required?","CJCS Priority","CJCSObjective","User Group",
           "OSE","OCE","Category","Event Types","Event Foci",
           "Special Interest Category","JWFC Support","JNTC",
           "JTF Certification","Event Level","Scope","Method Mode",
           "Location/Venue","Linked To Event","Linked From Event",
           "Event Team Lead","Deployment Start","Deployment End",
           "Redeployment Start","Redeployment End","Mil Air PAX",
           "Mil PAX Comments","Mil Air S Tons","Comm'l PAX",
           "Comm'l PAX Comments","Comm'l S Tons","APOD","Deployment Start",
           "Deployment End","Redeployment Start","Redeployment End","Sq Ft",
           "M Tons","PAX","PAX Comments","S Tons","SPOD","Deployment Start",
           "Deployment End","Redeployment Start","Redeployment End","Sq Ft",
           "PAX","PAX Comments","S Tons","POD","Milestone","Conference",
           "Start","End","Location","Registrants","CDC Milestone Start Date",
           "CDC Milestone End Date","IPC Milestone Start Date",
           "IPC Milestone End Date","MPC Milestone Start Date",
           "MPC Milestone End Date","FPC Milestone Start Date",
           "FPC Milestone End Date","Expense","ROM","Estimated Actual",
           "Budgeted","Actual","Class","Requirement ID","Requirement",
           "Amount of Available Funding","FTN","Service Line Item #","UTC",
           "JRC","# of Participants","Location","Start Date","End Date",
           "Reason","Provider","Recommended Source","Task/Purpose",
           "Capability","Status","Class","Requirement ID","Requirement",
           "FTN","Service Line Item #","Requested Location",
           "Providing Org UIC","Providing Org Name","Participating Org UIC",
           "Participating Org Name","# of Participants","Start Date",
           "End Date","Amount of Available Funding","Organization",
           "Affiliation Type","Source","Comments","Status","Class",
           "Requirement ID","FTN","Service Line Item #","UTC","Provider",
           "Recommended Source","Start Dates","End Dates","Requirement",
           "Amount of Available Funding","Task/Purpose","Capability",
           "Service","Grade","MOS","Security Clearance","# of Participants",
           "Location","Status","Class","Requirement ID","FTN",
           "Service Line Item #","Requirement","IA Name","UIC",
           "Organization Name","Organization Affiliation","Affiliation Type",
           "Start Date","End Date","Amount of Available Funding","Grade",
           "Security Clearance","Status","Class","Requirement ID",
           "Requirement Type","Opportunity/Benefit to Agency",
           "Amount of Available Funding","Reason","Organization",
           "Recommended Source","Unit/Organization","Start Date","End Date",
           "# of Participants","Requirement/Capability Required",
           "Federal (within AOR) Organization","Remarks/Comments","Status",
           "Class","ID","Requirement/Capability Required",
           "Opportunity/Benefit to Agency","Amount of Available Funding",
           "Reason","Organization","Source","Unit/Organization","Start Date",
           "End Date","Number of Participants","Status","Class",
           "Requirement ID","Requirement","Reason","Start Date","End Date",
           "Command","AOR/AOI","Participating Unit/Organization",
           "Number of Participants","Class","Requirement ID","Requirement",
           "Reason","Start Date","End Date","Organization",
           "Number of Participants","Class","Training Site Name","Location",
           "Comments","Start Date","End Date","Class","Live Simulation Name",
           "Start Date","End Date","Class","Virtual Simulation Name",
           "Start Date ","End Date","Class","Constructive Simulation Name",
           "Start Date","End Date"]

JTIMS_full_format = pd.DataFrame([row_one,row_two])


# pull out from the CPS data the subset of columns we're interested in for the
# JTIMS data and store it in it's own df for easier reference/formatting

# grab flag exercises (joint) and keep only columns we're simulating in JTIMS
JTIMS_data = CPS_data[['Event','Event #','Start','End']]\
                    .where(CPS_data['Event Type'] == "EXERCISES-FLAG").dropna()

JTIMS_data = JTIMS_data.drop_duplicates()

JTIMS_data['Year'] = [x.strftime('%y') for x in JTIMS_data['Start']]

JTIMS_data['str_num'] = None  
                                       
JTIMS_data['Events'] = JTIMS_data['Event'] + " " + JTIMS_data['Event #']
                                       
JTIMS_data['User Group'] = "HQ ACC"

JTIMS_data_prep = JTIMS_data[['Events','User Group','Start','End']]
JTIMS_data_prep.columns = [['Events','User Group','Start Date','End Date']]

# hand jam a couple of JTIMS events here (they won't have supporting squadrons)
empty_events = pd.DataFrame([
                             ['EMPTY FLAG 17-01',
                              'HQ ACC',
                              str(pd.to_datetime('2017-03-01')),
                              str(pd.to_datetime('2017-03-20'))
                             ],
                             ['EMPTY FLAG 18-01',
                              'HQ ACC',
                              str(pd.to_datetime('2018-01-04')),
                              str(pd.to_datetime('2018-01-25'))
                             ]
                            ], columns = JTIMS_data_prep.columns.tolist())

# build penultimate JTIMS dataframe   
JTIMS_data_penultimate = JTIMS_data_prep.append(empty_events,
                                                ignore_index = True)
data_width = len(JTIMS_full_format.columns)
records_num = len(JTIMS_data_penultimate)

for ii in range(records_num):
  temp_record = [[''] * data_width]

  # the columns of data we're actually looking to simulate are 1,8,9,23
  temp_record[0][1] = JTIMS_data_penultimate["Events"].iloc[ii]
  temp_record[0][8] = JTIMS_data_penultimate["Start Date"].iloc[ii]
  temp_record[0][9] = JTIMS_data_penultimate["End Date"].iloc[ii]
  temp_record[0][23] = JTIMS_data_penultimate["User Group"].iloc[ii]
  
  JTIMS_full_format = JTIMS_full_format.append(temp_record)

##############################################################################

#%%

##############################################################################
# Manually drop a few rows to make the deployments make sense
##############################################################################

# eyeball the dataframe and drop records as needed to ensure squadrons aren't
# deployed to multiple places at the same time and to make sure you didn't 
# randomly get too many squadrons assigned to a single deployment

# adjust as needed for aesthetic appeal of the final visualization
#CPS_data = CPS_data.drop([85,25,67,101])
                        
##############################################################################

#%%
      
##############################################################################
# Write out the fake data sets
##############################################################################
      
timestamp = datetime.now().strftime("%Y%m%d_%H%M_")
                             
# write out the result to the provided output filename
#CPS_data.to_csv(datapath + timestamp + outputFilename_CPS, index = False)  

#JTIMS_full_format.to_csv(datapath + timestamp + outputFilename_JTIMS,
#                         index = False,
#                         header = False)    
##############################################################################