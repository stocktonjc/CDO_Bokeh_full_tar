.. autoclass::  {{ module_name }}.{{ name }}
    :members:
    :undoc-members:
    :show-inheritance:

.. _{{ name }}.json:

.. collapsible-code-block:: javascript
    :heading: JSON Prototype

    {{ model_json|indent(4) }}
