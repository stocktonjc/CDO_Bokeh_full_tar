.. attribute:: {{ name }}
    :module: {{ module }}

    *property type:* {{ type_info }}

    {% if doc %}{{ doc|indent(4) }}{% endif %}
