'''
##############################################################################
#
# FILE: Bokeh_Visualization_Test_Gantt.py
#
#
# DESCRIPTION: Test of Bokeh package for calendar visualization
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20171027     James Stockton     Initial Coding
# 20171103     James Stockton     v0.1  (basic viz, sent to A3 for comments)
# 20171106     James Stockton     moved some data wrangling to data-ingest code
# 20171109     James Stockton     added date sliders and filter dropdown menu
# 20171113     James Stockton     added checkbox list and 'reset all' button
# 20171120     James Stockton     switched to dummy data, checkbox execution
# 20171121     James Stockton     added tabed views, v0.3 (it's live on AWS)
# 20171207     James Stockton     added Deploy/Dwell table
# 20171211     James Stockton     fixed table, added evene-based coloring
# 20171212     James Stockton     added deploy-dwell as x:y format v1.0 (live)
# 20171213     James Stockton     reformatted Dp:Dw based on feedback (minor)
# 20171218     James Stockton     added Ex:Dw, etc. and rearrange (v1.1)
# 20171219     James Stockton     begin work on feedback from Lt. Gen. Nowland
# 20171222     James Stockton     finished adding EKG + Wing-based focus (v1.2)
# 20180103     James Stockton     added dirname,realpath for datapath. cleanup
# 20180104     James Stockton     added MDS dropdown filter. cleanup. (v1.3)
# 20180108     James Stockton     adding in changes (A3 meeting on Fri. 5 Jan.)
# 20180117     James Stockton     finished changes from A3+Nowland (v1.4)
# 20180123     James Stockton     added comments, aligned charts (hand jam)
# 20180124     James Stockton     made a few minor speed optimizations
# 20180126     James Stockton     finished speed optimization efforts (v1.5)
# 20180202     James Stockton     minor requested aesthetic changes on tabs
#
# As of 20180202, v1.5 is live on CDO GovCloud                                  
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

from os.path import dirname, realpath, join

import pandas as pd
import numpy as np

import bokeh.models as bkm
import bokeh.plotting as bkp
import bokeh.layouts as bkl
import datetime as dt

from bokeh.palettes import Category20
from bokeh.palettes import brewer

from fractions import Fraction

import colorcet as cc

### !!! Save paths (comment/uncomment) as needed for tarball upload to AWS !!!

# Hardcoded data path allows Spyder to run (helpful during development)
# development machine, data path
datapath = "/home/stocktonjc/Coding/A3_CDO_Master_Exercise_Calendar/data/"
# AWS server, data path
#datapath = "/home/stocktonjc/A3_CDO_Master_Exercise_Calendar/data/"
                     
# Dynamically retrieve directory and build data path (used on server or 
# on dev. machine when testing with "cl> bokeh serve")
#my_directory = dirname(realpath(__file__))
#datapath = my_directory + "/data/"

# Set the datafile you want to work with
#datafile = "Unified_data_CPS_JTIMS_sample.csv"
#datafile = "Unified_Dummy_data_CPS_JTIMS_sample.csv"
datafile = "Unified_Dummy_data_CPS_JTIMS_SIPR_format_sample.csv"
#datafile = "tiny_Unified_Dummy_data_CPS_JTIMS_sample.csv"

##############################################################################

#%%

##############################################################################
# Import data, cast as datetime objects, etc.
##############################################################################

# read in joined data from CPS and JTIMS
working_data = pd.read_csv(datapath + datafile)

# cast the Start and End columns to datetime objects
working_data['Start_Date_JTIMS'] = pd.to_datetime(
                                              working_data['Start_Date_JTIMS'])
working_data['End_Date_JTIMS'] = pd.to_datetime(working_data['End_Date_JTIMS'])
working_data['Start_CPS'] = pd.to_datetime(working_data['Start_CPS'])
working_data['End_CPS'] = pd.to_datetime(working_data['End_CPS'])

# prep new column for Gantt_Unit veiw selection via radio button. Initially set
# it equal to Wing, but it's recalculated as needed later
working_data['plot_top_view'] = working_data['plot_top_Wing']
working_data['plot_bottom_view'] = working_data['plot_bottom_Wing']

# after finishing changes/additions to the visualization, these are the unused 
# columns dropped to speed calculation (as of v1.5)
drop_columns = ['Events_JTIMS', 'FTN_CPS','Events_no_spaces_JTIMS',
                'Event_Num_JTIMS', 'plot_top_Qty', 'str_Start_Date_JTIMS',
                'str_End_Date_JTIMS', 'Location_CPS','NAF_CPS','Homebase_CPS',
                'Event_Type_CPS', 'AsgnID_CPS', 'Events_CPS',
                'Events_no_spaces_CPS', 'plot_bottom_Qty',
                'fill_mapping_alpha_high']

working_data = working_data.drop(drop_columns, axis = 1)

# build empty dictionary from working_data
CDS_empty_dict = {column:[] for column in working_data.columns}

# build columndatasource for bokeh
CDS_plot = bkm.ColumnDataSource(data = CDS_empty_dict)

# prep description text
desc = bkm.Div(text = open(join(dirname(__file__), 
                      "Master_Exercise_Calendar_text.html")).read(), width=800)

tips = bkm.Div(text = open(join(dirname(__file__),"Widget_text.html")).read())

##############################################################################

#%%

##############################################################################
# Define unique name lists and other needed values
##############################################################################

unique_name_list = {"all":[],
                    "JTIMS":[],
                    "CPS":[],
                    "Sqdn":[],
                    "Wing":[],
                    "MDS":[],
                   }

def unique_name_list_update(temp_df, key_string, col_string):
  
  # Gather unique event names (sort them so as to match the ordering created by
  # the data merging code)
  unique_name_list[key_string] = sorted(temp_df[col_string]
                                                   .dropna().unique().tolist())

# run initial list creation
unique_name_list_update(working_data,"all","event_color")
unique_name_list_update(working_data,"JTIMS","Event_Name_JTIMS")
unique_name_list_update(working_data,"CPS","Event_CPS")
unique_name_list_update(working_data,"Sqdn","Sqdn_CPS")
unique_name_list_update(working_data,"Wing","Wing_CPS")
unique_name_list_update(working_data,"MDS","MDS_CPS")

# build dictionary of zeros for Dwell/Deploy by wing
wing_count = len(unique_name_list["Wing"])
temp_dict={       'Unit':np.full(wing_count, None).tolist(),
            'total_days':np.zeros(wing_count).tolist(),
              'all_days':np.zeros(wing_count).tolist(),
         'exercise_days':np.zeros(wing_count).tolist(),
           'deploy_days':np.zeros(wing_count).tolist(),
          'all_fraction':np.zeros(wing_count).tolist(),
     'exercise_fraction':np.zeros(wing_count).tolist(),
       'deploy_fraction':np.zeros(wing_count).tolist(),
             'all_dwell':np.empty(wing_count).tolist(),
        'exercise_dwell':np.empty(wing_count).tolist(),
          'deploy_dwell':np.empty(wing_count).tolist(),
           'event_count':np.zeros(wing_count).tolist()
          }

# build columndatasource for Dp:Dw table (wing)
deploy_plot = bkm.ColumnDataSource(data = temp_dict)


##############################################################################

#%%

##############################################################################
# Build User Input Controls (filters, sliders, etc.)
##############################################################################


# find the earliest date that exists in the dataset and pad it by 20 days
min_CPS_JTIMS_date = pd.datetime.date(min(working_data.Start_Date_JTIMS.min(),
                                          working_data.Start_CPS.min())
                                      - pd.to_timedelta(20,unit='D'))
                         
# find the latest date in the dataset and pad it by 20 days
max_CPS_JTIMS_date = pd.datetime.date(max(working_data.End_Date_JTIMS.max(),
                                          working_data.End_CPS.max())
                                      + pd.to_timedelta(20,unit='D'))

# define the maximum (padded) date range of the data
max_date_range=pd.date_range(start=min(working_data.Start_Date_JTIMS.min(),
                                       working_data.Start_CPS.min()),
                             end = max(working_data.End_Date_JTIMS.max(),
                                       working_data.End_CPS.max()))

# build the list of JTIMS events to populate the dropdown menu
JTIMS_selector_list = ["All",*unique_name_list["JTIMS"]]

# build the dropdown menu
JTIMS_selector = bkm.widgets.Select(title = "Filter by JTIMS Event",
                                    value = "All",
                                    options = JTIMS_selector_list)

# build the list to populate the dropdown menu for MDS selection
MDS_selector_list = ["All",*unique_name_list["MDS"]]

# build the MDS dropdown menu
MDS_selector = bkm.widgets.Select(title = "Filter by MDS",
                                  value = "All",
                                  options = MDS_selector_list)

# build the date sliders
min_date = bkm.DateSlider(title = "Choose Starting Date",
                          value = min_CPS_JTIMS_date,                         
                          start = min_CPS_JTIMS_date,
                          end = max_CPS_JTIMS_date,
                          step = 1)
# user_select() is the callback function for the date sliders. Setting a 
# throttle on them prevents millisecond level repeated calls during slides
#                          callback_policy = "throttle",
#                          callback_throttle = 250)

max_date = bkm.DateSlider(title = "Choose Ending Date",
                          value = max_CPS_JTIMS_date,
                          start = min_CPS_JTIMS_date,
                          end = max_CPS_JTIMS_date,
                          step = 1)
# user_select() is the callback function for the date sliders. Setting a 
# throttle on them prevents millisecond level repeated calls during slides.
# Unfortunately, this is apparently not implemented for 'bokeh serve' as of 
# version 0.12.13. Maybe a future release will fix it.
#                          callback_policy = "throttle",
#                          callback_throttle = 250)

# build the list of MAJCOMS for the checkboxes. This seems like it could be
# tracked by another entry in unique_name_list, but those change based on user
# input and the checkbox_list needs to know all of the MAJCOMs even when
# they're de-selected
unique_MAJCOM_list = sorted(working_data['MAJCOM_CPS']
                                        .dropna()
                                        .unique()
                                        .tolist())

# build the checkbox list
MAJCOM_checkbox = bkm.widgets.CheckboxGroup(name = 'Choose MAJCOMs',
                                           labels = unique_MAJCOM_list,
                   active = list(np.arange(0,len(unique_MAJCOM_list))))

# use a text box to create a label/title for the checkboxes
checkbox_title = bkm.widgets.Div(text = '''Select Desired MAJCOMs''')

# build a button to reset all user inputs to defaults
select_all = bkm.widgets.Button(label = "Reset All Filters")

# declare the button that will update the data table
update_dwell = bkm.widgets.Button(label = "Update Data Table")

# declare the pair of radio buttons to choose Wing or Squadron view
view_selector = bkm.widgets.RadioGroup(labels = ['Wing view','Squadron view'],
                                       active = 0
                                       )


# build an ordered list of all user inputs for display
# leave update_dwell out of the list b/c we want it elsewhere on the screen
controls = [select_all,
            view_selector,
            JTIMS_selector,
            min_date,
            max_date,
            checkbox_title,
            MAJCOM_checkbox,
            MDS_selector]


##############################################################################

#%%

##############################################################################
# Define callbacks and data update functions when given user input
##############################################################################


# find a given Wing's postion in the list for plotting positions correctly
def Wing_y_position_mapper(string):
    return int(unique_name_list['Wing'].index(string))

# find a given Squadron's postion in the list for plotting positions correctly
def Sqdn_y_position_mapper(string):
    return int(unique_name_list['Sqdn'].index(string)) 


# Use the current settings of the widgets to filter the data
def user_select():
      
    # use the date slider positions to filter the data down to a subset    
    selected = working_data[
              ( (working_data.Start_Date_JTIMS >= min_date.value) |
                (working_data.Start_CPS >= min_date.value) ) &
              ( (working_data.End_Date_JTIMS <= max_date.value) |
                (working_data.End_CPS <= max_date.value) )
              ].copy()
 
    # filter down by the selected JTIMS event if needed
    if (JTIMS_selector.value != "All"):
    
        selected = selected[selected.Event_Name_JTIMS.str.contains(
                                            JTIMS_selector.value)==True]
    
    # filter down by the selected MDS event if needed
    if (MDS_selector.value != "All"):
    
        selected = selected[selected.MDS_CPS.str.contains(
                                              MDS_selector.value)==True]      
            
    # build a list of checkbox indices currently checked (active)  
    MAJCOM_checked_index_list = list(MAJCOM_checkbox.active)
    
    # check if there are any de-selected MAJCOMs. Don't bother with the filter
    # loop if they're all checked (to speed computation/interaction)
    if(len(MAJCOM_checkbox.active) != len(unique_MAJCOM_list)):

      # prep a temporary copy of the currently selected data
      temp = selected.copy()
    
      # loop through each checked box to get a dataframe of rows we DON'T want 
      for MAJCOM_index in MAJCOM_checked_index_list:
        # grab the MAJCOM text given the index position in the MAJCOM list
        MAJCOM = unique_MAJCOM_list[MAJCOM_index]      
        # filter !!! OUT !!! the desired majcom
        temp = temp[(temp.MAJCOM_CPS.str.contains(MAJCOM) == False)]
    
      # temp is now all rows we don't want; since it's a strict subset of the 
      # whole dataset, a merge just results in the whole dataset with new field
      # indicating which rows were found in which dataframe
      temp2 = pd.merge(selected, temp, how = 'outer', indicator = True)
    
      # keep desired rows by dropping anything found in temp during the merge
      selected = temp2[temp2._merge == 'left_only'].drop('_merge', axis = 1)

    # update the unique_name_list dictionary based on current selections
    # this allows the y-axes of the Gantt charts to display only selected units
    # not all lists in the dict need to be updated
#    unique_name_list_update(selected)  
#    unique_name_list_update(selected,"all","event_color")
#    unique_name_list_update(selected,"JTIMS","Event_Name_JTIMS")
#    unique_name_list_update(selected,"CPS","Event_CPS")
#    unique_name_list_update(selected,"Sqdn","Sqdn_CPS")
#    unique_name_list_update(selected,"Wing","Wing_CPS") 
#    unique_name_list_update(selected,"MDS","MDS_CPS")
#    unique_name_list_update(selected,"MAJCOM","MAJCOM_CPS")


    # setting these directly (hard coded rather than sent to the function)
    # saves a little on run time of user_select. This may not really matter
    # b/c I think the limiting factor is the rend speed on the javascript side.
    unique_name_list['Sqdn'] = sorted(selected['Sqdn_CPS']
                                                   .dropna().unique().tolist())

    unique_name_list['Wing'] = sorted(selected['Wing_CPS']
                                                   .dropna().unique().tolist())


    # if wing is selected, recalculate wing plot locations
    if view_selector.active == 0:

      Gantt_Unit.y_range.factors = unique_name_list["Wing"]
      
      wing_position_list = selected.loc[selected['Wing_CPS'].notnull(),
                                        'Wing_CPS'].map(Wing_y_position_mapper)
      
      # recalculate the plot positions based on the new list of categories
      selected.loc[selected['Wing_CPS'].notnull(), 'plot_top_Wing'] = 0.75 + \
                                                             wing_position_list

      selected.loc[selected['Wing_CPS'].notnull(), 'plot_bottom_Wing'] = 0.25+\
                                                             wing_position_list
    
      selected['plot_top_view'] = selected['plot_top_Wing']
      selected['plot_bottom_view'] = selected['plot_bottom_Wing']


    # if Squadron is selected, recalculate Squadron plot locations
    else:
  
      Gantt_Unit.y_range.factors = unique_name_list["Sqdn"]

      sqdn_position_list = selected.loc[selected['Sqdn_CPS'].notnull(),
                                        'Sqdn_CPS'].map(Sqdn_y_position_mapper)
      

      selected.loc[selected['Sqdn_CPS'].notnull(), 'plot_top_Sqdn'] = 0.75 + \
                                                             sqdn_position_list

      selected.loc[selected['Sqdn_CPS'].notnull(), 'plot_bottom_Sqdn'] = 0.25+\
                                                             sqdn_position_list

      selected['plot_top_view'] = selected['plot_top_Sqdn']
      selected['plot_bottom_view'] = selected['plot_bottom_Sqdn']
        
    return selected


# Bokeh uses column data stores as the base data format. re-initializaing the
# CDS each time a change occurs clears out all data to ensure we've got only
# the currently selected/filtered data
def update():
  
    # get the current data based on the current settings of the filters, etc.
    df_temp = user_select()
    
    # rebuilding the data for Bokeh this way allows for interactions, etc.
#    CDS_plot.data = {column:df_temp[column] for column in df_temp.columns}
    # alternate method (ends up with essentially the same runtime)
    CDS_plot.data = df_temp.to_dict(orient = 'series')
    
    # find the min/max event dates in the currently selected data
    current_min_date = min(CDS_plot.data['Start_Date_JTIMS'].min(),
                           CDS_plot.data['Start_CPS'].min())\
                       - pd.to_timedelta(20,unit='D')
    
    current_max_date = max(CDS_plot.data['End_Date_JTIMS'].max(),
                           CDS_plot.data['End_CPS'].max())\
                       + pd.to_timedelta(20,unit='D')
    
    # reset x_range on EKG and stacked_areas to match date sliders. 
    # (there's a whole bunch of BS here to make javascript happy: pad date 
    # with seconds, shift by the zero-point (1970), convert to timedelta as
    # seconds, then convert to milliseconds)
    min_date_js = int((dt.datetime.combine(current_min_date,
                                           dt.datetime.min.time())
                                         - dt.datetime(1970,1,1))
                      / dt.timedelta(seconds = 1)) * 1e3
    
    max_date_js = int((dt.datetime.combine(current_max_date,
                                           dt.datetime.min.time())
                                         - dt.datetime(1970,1,1))
                      / dt.timedelta(seconds = 1)) * 1e3
    
    EKG_MAJCOM.x_range.start = min_date_js
    EKG_MAJCOM.x_range.end = max_date_js
    stacked_areas.x_range.start = min_date_js
    stacked_areas.x_range.end = max_date_js
    


# reset all widgets to their default vaules and update the data    
def reset_all():
   
    # set all of the users selections to their chosen default values
    JTIMS_selector.value = "All"
    MDS_selector.value = "All"
    MAJCOM_checkbox.active = list(np.arange(0,len(unique_MAJCOM_list)))
    min_date.value = min_CPS_JTIMS_date
    max_date.value = max_CPS_JTIMS_date
    
    # filter the data based on the new settings
    update()


# populate the data table based on current user selections    
def crunch_table_data():
   
    df_temp = user_select()
    
    date_range = (max_date.value - min_date.value).days
    
    
    # build Deploy:Dwell dictionary based on Wing/Sqdn selection
    if view_selector.active == 0: # Wing is selected
      temp_dict={   'Unit':unique_name_list["Wing"],
              'total_days':np.zeros(len(unique_name_list["Wing"])).tolist(),
                'all_days':np.zeros(len(unique_name_list["Wing"])).tolist(),
           'exercise_days':np.zeros(len(unique_name_list["Wing"])).tolist(),
             'deploy_days':np.zeros(len(unique_name_list["Wing"])).tolist(),
            'all_fraction':np.zeros(len(unique_name_list["Wing"])).tolist(),
       'exercise_fraction':np.zeros(len(unique_name_list["Wing"])).tolist(),
         'deploy_fraction':np.zeros(len(unique_name_list["Wing"])).tolist(),
               'all_dwell':np.empty(len(unique_name_list["Wing"])).tolist(),
          'exercise_dwell':np.empty(len(unique_name_list["Wing"])).tolist(),
            'deploy_dwell':np.empty(len(unique_name_list["Wing"])).tolist(),
             'event_count':np.zeros(len(unique_name_list["Wing"])).tolist()
              }
    else: # squadron is selected
      temp_dict={   'Unit':unique_name_list["Sqdn"],
              'total_days':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
                'all_days':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
           'exercise_days':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
             'deploy_days':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
            'all_fraction':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
       'exercise_fraction':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
         'deploy_fraction':np.zeros(len(unique_name_list["Sqdn"])).tolist(),
               'all_dwell':np.empty(len(unique_name_list["Sqdn"])).tolist(),
          'exercise_dwell':np.empty(len(unique_name_list["Sqdn"])).tolist(),
            'deploy_dwell':np.empty(len(unique_name_list["Sqdn"])).tolist(),
             'event_count':np.zeros(len(unique_name_list["Sqdn"])).tolist()
              }

    # feed the zeros to a dataframe
    deploy_df = pd.DataFrame(data = temp_dict)
        
    if view_selector.active == 0: # wing selected
      unit_list = unique_name_list['Wing']
      unit_column = 'Wing_CPS'
    else: # sqdn selected
      unit_list = unique_name_list['Sqdn']
      unit_column = 'Sqdn_CPS'


    # prepare a count of the number of sqadrons in a wing. If we're calculating
    # by squadrons then it will eventually evaluate to 1 and doesn't matter.
    # It's needed to correct Dp:Dw when using Sqdn/Wing radio buttons
    group_by_unit  = df_temp.groupby(df_temp[unit_column])
    unit_count = group_by_unit.Sqdn_CPS.unique()
    

    # loop through each unit and count the days they're "deployed"
    for unit in unit_list:
 
      # count up Sqdn in the Wing (if calculating by Sqdn, this will eval to 1)
      DpDw_modifier = int(len(unit_count[unit]))

      # cut the filtered dataset down to just the current unit
      temp = df_temp.loc[df_temp[unit_column] == unit, ['Msn_Area_CPS',
                                                        'Start_CPS',
                                                        'End_CPS']
                                                       ]
   
      all_day_counter = 0
      deploy_day_counter = 0
      exercise_day_counter = 0
 
      if len(temp) > 0:
        # loop through the records (events) for the current wing
        for ii in range(len(temp)):  
        
          # count up days if it's a deployment
          if temp['Msn_Area_CPS'].iloc[ii] == "OCONUS":
                   deploy_day_counter = deploy_day_counter + \
                   (temp['End_CPS'].iloc[ii] - temp['Start_CPS'].iloc[ii]).days

          # count up days if it's an exercise (i.e. not a deployment)
          if temp['Msn_Area_CPS'].iloc[ii] != "OCONUS":
                   exercise_day_counter = exercise_day_counter + \
                   (temp['End_CPS'].iloc[ii] - temp['Start_CPS'].iloc[ii]).days
        
          # count up all days (exercise + deployment)
          all_day_counter = all_day_counter + \
                   (temp['End_CPS'].iloc[ii] - temp['Start_CPS'].iloc[ii]).days
  
        # modify counts to rectify results with Sqdn vs. Wing level view
        deploy_day_counter = deploy_day_counter / DpDw_modifier
        exercise_day_counter = exercise_day_counter / DpDw_modifier
        all_day_counter = all_day_counter / DpDw_modifier
        
        # fill in the data for the current unit
        deploy_df.loc[deploy_df["Unit"]==unit, 'total_days'] = date_range
        
        deploy_df.loc[deploy_df["Unit"]==unit,'all_days']=all_day_counter
        
        deploy_df.loc[deploy_df["Unit"] == unit, 'all_fraction'] = \
                                         round(all_day_counter / date_range, 2)
      
        deploy_df.loc[deploy_df["Unit"] == unit, 'exercise_days'] = \
                                                           exercise_day_counter
        
        deploy_df.loc[deploy_df["Unit"] == unit, 'exercise_fraction'] = \
                                    round(exercise_day_counter / date_range, 2)
           
        deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_days'] = \
                                                             deploy_day_counter
        
        deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_fraction'] = \
                                      round(deploy_day_counter / date_range, 2)

        deploy_df.loc[deploy_df["Unit"] == unit, 'event_count'] = len(temp) 
          
        
        # build all:Dwell ratio as 1:x rather then y:z 
        odds_num_left_as_str_all = str(1)
        
        all_fraction_denominator = Fraction(round(
                                      (all_day_counter/date_range), 2))\
                                      .limit_denominator(max_denominator = 20)\
                                      .denominator
        
        all_fraction_numerator = Fraction(round(
                                      (all_day_counter / date_range), 2))\
                                      .limit_denominator(max_denominator = 20)\
                                      .numerator
       
        if all_fraction_numerator != 0:
          all_numerator_divisor = all_fraction_numerator
       
        else:
          all_numerator_divisor = 1
     

        odds_num_right_as_str_all = str(round(
                             ((all_fraction_denominator-all_fraction_numerator)
                             / all_numerator_divisor), 2))
        
        all_printable_dwell = str(odds_num_left_as_str_all + ":" +
                                  odds_num_right_as_str_all)
        
        deploy_df.loc[deploy_df["Unit"] == unit, 'all_dwell'] = \
                                                            all_printable_dwell        

        # build Exercise:Dwell ratio as 1:x rather then y:z 
        if(exercise_day_counter != 0):
          odds_num_left_as_str_exercise = str(1)
          
          exercise_fraction_denominator = Fraction(round(
                                      (exercise_day_counter/date_range), 2))\
                                      .limit_denominator(max_denominator = 20)\
                                      .denominator
          
          exercise_fraction_numerator = Fraction(round(
                                      (exercise_day_counter / date_range), 2))\
                                      .limit_denominator(max_denominator = 20)\
                                      .numerator
          
          if exercise_fraction_numerator != 0:
            ex_numerator_divisor = exercise_fraction_numerator
        
          else:
            ex_numerator_divisor = 1
        
          odds_num_right_as_str_exercise = str(round(
                   ((exercise_fraction_denominator-exercise_fraction_numerator)
                   / ex_numerator_divisor), 2))
        
          exercise_printable_dwell = str(odds_num_left_as_str_exercise +":"+
                                         odds_num_right_as_str_exercise)
        
          deploy_df.loc[deploy_df["Unit"] == unit, 'exercise_dwell'] = \
                                                       exercise_printable_dwell        
        
        else:
   
          deploy_df.loc[deploy_df["Unit"]==unit,'exercise_dwell'] = "0:0"
        
        # build Deploy:Dwell ratio as 1:x rather then y:z 
        if(deploy_day_counter != 0):        
          odds_num_left_as_str_deploy = str(1)
        
          deploy_fraction_denominator = Fraction(round(
                                      (deploy_day_counter/date_range), 2))\
                                      .limit_denominator(max_denominator = 20)\
                                      .denominator
        
          deploy_fraction_numerator = Fraction(round(
                                      (deploy_day_counter / date_range), 2))\
                                      .limit_denominator(max_denominator = 20)\
                                      .numerator

          if deploy_fraction_numerator != 0:
            dp_numerator_divisor = deploy_fraction_numerator
        
          else:
            dp_numerator_divisor = 1

          odds_num_right_as_str_deploy = str(round(
                   ((deploy_fraction_denominator-deploy_fraction_numerator)
                   / dp_numerator_divisor), 2))
        
          deploy_printable_dwell = str(odds_num_left_as_str_deploy + ":" +
                                       odds_num_right_as_str_deploy)
        
          deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_dwell'] = \
                                                         deploy_printable_dwell        
        else:
          deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_dwell'] = "0:0"
          

      else:
        deploy_df.loc[deploy_df["Unit"] == unit, 'total_days'] = date_range        
        deploy_df.loc[deploy_df["Unit"] == unit, 'all_days'] = 0        
        deploy_df.loc[deploy_df["Unit"] == unit, 'exercise_days'] = 0
        deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_days'] = 0
        deploy_df.loc[deploy_df["Unit"] == unit, 'all_fraction'] = 0.0
        deploy_df.loc[deploy_df["Unit"] == unit, 'exercise_fraction'] = 0.0
        deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_fraction'] = 0.0
        deploy_df.loc[deploy_df["Unit"] == unit, 'all_dwell'] = "0:0"
        deploy_df.loc[deploy_df["Unit"] == unit, 'exercise_dwell'] ="0:0"
        deploy_df.loc[deploy_df["Unit"] == unit, 'deploy_dwell'] = "0:0"
        deploy_df.loc[deploy_df["Unit"] == unit, 'event_count'] = 0
              

    df_sort = deploy_df.sort_values(['Unit'], ascending = [False])
    
    deploy_plot.data={col:df_sort[col] for col in df_sort.columns}    
    


# EKG plot data preparation function
def patch_data_prep(category, data, scale=1):
    return list(zip([category]*len(data), scale*data))

# EKG data aggregation function
def LOE_measure(dt_rng_x, df_subset):  
  
  # prep a list of zeros to store level-of-effort counts
  LOE_fraction = np.zeros(len(dt_rng_x)).tolist()      
  # Qty_max is the same for every record for a given Squadron. So, group by 
  # Sqdns, select unique instances, and sum up the airframes. This gives a 
  # count of the total number of frames available at the organizational level
  # represented in df_subset (Wing, MAJCOM, all AF) 
  total_airframes_temp = df_subset.groupby(df_subset['Sqdn_CPS'])
  total_airframes = total_airframes_temp['Qty_max_CPS'].unique().sum()[0]
  
  for ii, date in enumerate(dt_rng_x):  
    LOE_fraction[ii] = df_subset.loc[( (df_subset['Start_CPS'] <= date) &
                                       (df_subset['End_CPS'] >= date) 
                                     ),  'Qty_CPS'].sum() / total_airframes
  return LOE_fraction



# define the behavior for each of the interactive widgets
JTIMS_selector.on_change('value', lambda attr, old, new: update())
MDS_selector.on_change('value', lambda attr, old, new: update())
view_selector.on_change('active', lambda attr, old, new: update())
min_date.on_change('value', lambda attr, old, new: update())
max_date.on_change('value', lambda attr, old, new: update())
MAJCOM_checkbox.on_change('active', lambda attr, old, new: update())
select_all.on_click(reset_all)
update_dwell.on_click(crunch_table_data)

my_sizing_mode = 'fixed' # 'fixed'  # 'scale_width' # (other option(s) ?)
       
# add all of the widgets for display
inputs = bkm.WidgetBox(*controls, sizing_mode = my_sizing_mode)

##############################################################################

#%%

##############################################################################
# Define event color coding palette
##############################################################################

# Build list of category colors based on the number of unique event names
if len(unique_name_list["all"]) > 2:  
  color_palette_events = Category20[len(unique_name_list["all"])]

elif len(unique_name_list["all"]) == 2:
  color_palette_events = [Category20[3][0],Category20[3][1]]

else:
  color_palette_events = [Category20[3][0]]  

##############################################################################

#%%

##############################################################################
# Build the JTIMS Event Gantt chart
##############################################################################

# Make a CategoricalColorMapper object
color_mapper_JTIMS = bkm.CategoricalColorMapper(
                                             factors = unique_name_list["all"],
                                             palette = color_palette_events)


# find the date range for JTIMS events
#JTIMS_date_range = bkm.Range1d(min_CPS_JTIMS_date, max_CPS_JTIMS_date)

# declare the initial figure
Gantt_JTIMS = bkp.figure(title = 'JTIMS Calendar',
                         x_axis_type = 'datetime',
                         width = 1000,
                         height = 300,
                         y_range = unique_name_list["JTIMS"],                                             
# explicitly setting the xrange here prevents the 'zoom in' effect when using
# the date range sliders. (Fixed vs. Dynamic time axis)
#                         x_range = JTIMS_date_range,
                         tools = 'reset,box_zoom,hover,tap')

# build the hovetTool (mouse-over information)
hover_JTIMS = Gantt_JTIMS.select(type=bkm.HoverTool)[0]
hover_JTIMS.tooltips =  [('Squadron','@Sqdn_CPS'),
                         ('Qty','@Qty_CPS' +' , '+'@MDS_CPS'),
                         ('JTIMS User Group','@User_Group_JTIMS')
                        ]

# build the glyphs for each individual event
Gantt_JTIMS.quad(left = 'Start_Date_JTIMS',
                 right = 'End_Date_JTIMS',
                 top = 'plot_top_JTIMS',
                 bottom = 'plot_bottom_JTIMS',
                 fill_alpha = 'fill_mapping_alpha_low',
#               legend = 'Event_Name_JTIMS',
                 source = CDS_plot,
                 color = dict(field = 'event_color',
                              transform = color_mapper_JTIMS),
                 line_color = 'black',
                 line_width = 1.5,
                 selection_color = "black"
                )

##############################################################################

#%%

##############################################################################
# Build the CPS Event Gantt chart
##############################################################################


# Make a CategoricalColorMapper object
color_mapper_CPS=bkm.CategoricalColorMapper(factors = unique_name_list["all"],
                                            palette = color_palette_events)


# find the date range for CPS events
#CPS_date_range = bkm.Range1d(min_CPS_JTIMS_date, max_CPS_JTIMS_date)


# declare the initial figure
Gantt_CPS = bkp.figure(title = 'CPS Calendar',
                       x_axis_type = 'datetime',
                       width = 1000,
                       height = 300,
                       y_range = unique_name_list["CPS"],
                       # set to match other figure's date range
                       x_range = Gantt_JTIMS.x_range,
                       tools = 'reset,box_zoom,hover,tap')


# build the hoverTool (mouse-over text) for CPS events
hover_CPS = Gantt_CPS.select(type=bkm.HoverTool)[0]
hover_CPS.tooltips =  [('Event #','@Event_Num_CPS'),
                       ('Wing','@Wing_CPS'),
                       ('Qty','@Qty_CPS' +' , '+'@MDS_CPS')
                      ]

# build the individual event glyphs 
Gantt_CPS.quad(left = 'Start_CPS',
               right = 'End_CPS',
               top = 'plot_top_CPS',
               bottom = 'plot_bottom_CPS',
               fill_alpha = 'fill_mapping_alpha_low',
#             legend = 'Event_Name_JTIMS',
               source = CDS_plot,
               color = dict(field = 'event_color',
                            transform = color_mapper_CPS),
               line_color = 'black',
               line_width = 1.5,
               selection_color = "black"
              )

##############################################################################

#%%

##############################################################################
# Build the Wing Gantt chart
##############################################################################


# Make a CategoricalColorMapper object
color_mapper_unit=bkm.CategoricalColorMapper(factors = unique_name_list["all"],
                                             palette = color_palette_events)


# declare the initial figure
Gantt_Unit = bkp.figure(title = 'Event Calendar by Wing/Squadron',
                       x_axis_type = 'datetime',
                       width = 1000,
                       height = 400,
                       y_range = unique_name_list["Wing"],
                       # set to match the date range of JTIMS figure
                       x_range = Gantt_JTIMS.x_range,
                       tools = 'reset,hover')

Gantt_Unit.yaxis.major_label_text_font_size = '10pt'  

# build the hoverTool (mouse-over text) for the wing events
hover_wing = Gantt_Unit.select(type=bkm.HoverTool)[0]
hover_wing.tooltips =  [('Event','@Event_Name_CPS'),
                            ('Squadron','@Sqdn_CPS'),
                            ('Qty, MDS','@Qty_CPS' +' , '+'@MDS_CPS'),
                            ('Mission Area','@Msn_Area_CPS'),
#                            ('Objectives','@Note_CPS'),
                            ('Start','@str_Start_Date_CPS'),
                            ('End','@str_End_Date_CPS')
                           ]

# build the individual event glyphs
Gantt_Unit.quad(left = 'Start_CPS',
                right = 'End_CPS',
                top = 'plot_top_view',
                bottom = 'plot_bottom_view',
                fill_alpha = 'fill_mapping_alpha_low',
#              legend = 'Event_Name_JTIMS',
                source = CDS_plot,
                color = dict(field = 'event_color',
                             transform = color_mapper_unit),
                line_color = 'black',
                line_width = 1.5,
               )

# !!! not currently implemented !!! 
#==============================================================================
# # Build glyphs with tops proportional to the fraction of squadron committed.
# # When overplotted with the other quads it will create what appears to be a 
# # single quad 'filled' with a darker color up to a level showing the fraction
# # of the unit committed to that event
# Gantt_Unit.quad(left = 'Start_CPS',
#            right = 'End_CPS',
#            top = 'plot_top_Qty',
#            bottom = 'plot_bottom_Qty',
#            fill_alpha = 'fill_mapping_alpha_low',
# #           legend = 'Event_Name_JTIMS',
#            source = CDS_plot,
#            color = dict(field = 'event_color',
#                         transform = color_mapper_wing),
#            line_color = 'black',
#            line_width = 1.5,
#            )
#==============================================================================
           

##############################################################################

#%%

##############################################################################
# Build the Dwell/Deploy table
##############################################################################

# add a custom javascript block to define the HTML colors of data table cells
color_conditional = '''
<div style="background:<%=
    (function colorfromint(){
        if (value >= 0.4)  {
            return("#FF8181")
        } else if (value >= 0.333333333) {
            return("#FBFF81")
        } else if (value > 0.0) {
            return("#88FF81")}
        else{return("#FFFFFF")}
      }()) %>;
    color: black">
<%= value %></div>
'''

color_coder = bkm.widgets.HTMLTemplateFormatter(template = color_conditional)

columns = [
           bkm.widgets.TableColumn(field = "Unit",
                                   title = "Unit",
                                   width = 62), 

#           bkm.widgets.TableColumn(field = "event_count",
#                                   title = "Events",
#                                   width = 25), 

#           bkm.widgets.TableColumn(field = "total_days",
#                                   title = "Tot. Days",
#                                   width = 25),
                                   
#           bkm.widgets.TableColumn(field = "all_days",
#                                   title = "all sched.",
#                                   width = 25),
                                   
           bkm.widgets.TableColumn(field = "all_fraction",
                                   title = "Fraction",
                                   formatter = color_coder,
                                   width = 53),

           bkm.widgets.TableColumn(field = "all_dwell",
                                   title = "all:Dw",
                                   width = 43),
           
#           bkm.widgets.TableColumn(field = "exercise_days",
#                                   title = "Ex. sched.",
#                                   width = 25),
                                   
           bkm.widgets.TableColumn(field = "exercise_fraction",
                                   title = "Ex. Frac.",
                                   width = 53,
                                   formatter = color_coder),

           bkm.widgets.TableColumn(field = "exercise_dwell",
                                   title = "Ex:Dw",
                                   width = 47),

#           bkm.widgets.TableColumn(field = "deploy_days",
#                                   title = "Deploy sched.",
#                                   width = 25),
                                   
           bkm.widgets.TableColumn(field = "deploy_fraction",
                                   title = "Deploy Frac.",
                                   width = 69,
                                   formatter = color_coder),

           bkm.widgets.TableColumn(field = "deploy_dwell",
                                   title = "Dp:Dw",
                                   width = 47) 
           ]
# pixel counts of the individual columns must add up to the pixel width
# provided in the table definition. Otherwise, it will auto-assign ~equal 
# column-widths to fill the space defined in the table. I hardcoded the numbers
# to make everything display correctly. You could probably do some ratio-ing
# of the column titles to scale everything in a slightly less hand-jam-y way
data_table = bkm.widgets.DataTable(source = deploy_plot,
                                   columns = columns,
                                   width = 374,
                                   height = 500,
                                   row_headers = False)

##############################################################################

#%%

##############################################################################
# build 'EKG' style level-of-effort 
##############################################################################


# prep label for AF-wide LOE
AF_wide = ["AF-wide"]

# define color palette for EKG (MAJCOMs + AF_wide)
palette=[cc.rainbow[jj*15] for jj in range(len(unique_MAJCOM_list)+1)]


# declare the initial figure
EKG_MAJCOM = bkp.figure(title = 'Level-of-Effort EKG',
                        x_axis_type = 'datetime',
                        width = 1000,
                        height = 300,
                        # add an empty string to the list for visibility on AF
                        y_range = [*unique_MAJCOM_list,AF_wide[0],""],
#                        y_range = [*unique_name_list["Wing"], "-", "", " "],
                        # set to match the date range of JTIMS figure
#                        x_range = Gantt_JTIMS.x_range,
                        toolbar_location = None)

EKG_MAJCOM.yaxis.major_label_text_font_size = '10pt'
EKG_MAJCOM.outline_line_color = None
EKG_MAJCOM.background_fill_color = "#efefef"
  
# define the date range defined by min/max (user can update later)
date_range = pd.date_range(start = min_date.value-pd.to_timedelta(20,unit='D'),
                           end = max_date.value+pd.to_timedelta(20,unit='D'))            

# declare inital CDS for EKG plot
source_EKG = bkm.ColumnDataSource(data=dict(date_range = date_range))
  

# prep an LOE df for storage of LOE data. Used for Stacked Areas chart later
# to avoid recalculation
LOE_data = {MAJCOM:[] for MAJCOM in unique_MAJCOM_list}
LOE_df = pd.DataFrame(data = LOE_data)

# loop through each MAJCOM and calculate the Level-of-effort line
for jj, unit in enumerate([*unique_MAJCOM_list, AF_wide[0]]):
    
  if jj < len(unique_MAJCOM_list):
    LOE_line = LOE_measure(date_range,
                           working_data[['Sqdn_CPS','Qty_CPS','Qty_max_CPS',
                                         'Start_CPS','End_CPS']]
                                    .loc[working_data['MAJCOM_CPS'] == unit])
    LOE_line[0] = 0.0
    LOE_line[-1] = 0.0
    y = patch_data_prep(unit, LOE_line)
    source_EKG.add(y, unit)
    EKG_MAJCOM.patch('date_range',
                     unit,
                     color=palette[jj],
                     alpha=0.6,
                     name = unit,
                     source=source_EKG)
    LOE_df[unit] = LOE_line
  
  else:
  # Calculate LOE for the entire dataset (AF-wide)
    LOE_line = LOE_measure(date_range,
                            working_data[['Sqdn_CPS','Qty_CPS','Qty_max_CPS',
                                          'Start_CPS','End_CPS']])
    LOE_line[0] = 0.0
    LOE_line[-1] = 0.0
    y = patch_data_prep(unit, LOE_line)
    source_EKG.add(y, unit)
    EKG_MAJCOM.patch('date_range',
                     unit,
                     color=palette[jj],
                     alpha=0.6,
                     name = unit,
                     source=source_EKG)

##############################################################################

#%%

##############################################################################
# build stacked area style level-of-effort chart 
##############################################################################

# change index to display dates correctly 
LOE_df.index = date_range

def stacked(df):
    df_top = df.cumsum(axis=1)
    df_bottom = df_top.shift(axis=1).fillna({'y0': 0})[::-1]
    df_stack = pd.concat([df_bottom, df_top], ignore_index=True)
    return df_stack

areas = stacked(LOE_df)
colors = brewer['Spectral'][areas.shape[1]]
#colors = [palette[ii] for ii in range(len(unique_MAJCOM_list))]
x2 = np.hstack((LOE_df.index[::-1], LOE_df.index))

stacked_areas = bkp.figure(title = "Stacked AF-wide Level-of-Effort by MAJCOM",
                           y_range = (0, 1.0),
                           width = 1000,
                           height = 300,
                           x_axis_type = 'datetime')

stacked_areas.yaxis.major_label_text_font_size = '10pt' 
stacked_areas.grid.minor_grid_line_color = '#eeeeee'

# normalize to [0,1] (percentage of AF-wide airframes)
count = len(unique_MAJCOM_list)

for ii, unit in enumerate(sorted(unique_MAJCOM_list)):
  stacked_areas.patch(x2,
                      (areas[unit].values / count),
                      color=colors[ii],
                      alpha=0.8,
                      line_color=None,
                      legend = unique_MAJCOM_list[ii])

##############################################################################

#%%

##############################################################################
# Update data based on current settings, build and display the final layout
##############################################################################

# hand jam some borders to fudge the alignment of the Gantt charts. This is
# needed b/c the 'tabbed layout' in Bokeh doesn't play nice with the auto-
# alignment in the Row/Column layouts.

# LEFT SIDE ALIGNMENT
# The y-axis labels for CPS_Gantt are the longest; so, it drives the placement.
# Eveything else is matched up to that y-axis location.
# Since Gantt_Unit is the only chart not in the same layout as Gantt_CPS, 
# it ends up with a different value       
Gantt_Unit.min_border_left = 171
EKG_MAJCOM.min_border_left = 160           
stacked_areas.min_border_left = 160        
Gantt_JTIMS.min_border_left = 160

# RIGHT SIDE ALIGNMENT
# The right side extent of the x-axis for Gantt_Unit is shortest; so, it drives
# the placement. Eveything else is matched up to that location.      
# Since all four are in the same layout, they get the same padding
Gantt_CPS.min_border_right = 42
EKG_MAJCOM.min_border_right = 42         
stacked_areas.min_border_right = 42        
Gantt_JTIMS.min_border_right = 42

# Other options for hand-jamming the alignment (not currently used)
#Gantt_JTIMS.yaxis.axis_label = ' '
#Gantt_JTIMS.yaxis.axis_label_text_font_size = '22pt'
#EKG_MAJCOM.y_range.range_padding = 0.12
#EKG_MAJCOM.x_range.start = 0.4

# initial load of the data 
update()

# populate the data table based on current inputs
crunch_table_data()

# add the JTIMS and CPS event Gantt charts to a tabbed object
tab1 = bkm.widgets.Panel(child = Gantt_JTIMS,   title = 'JTIMS')
tab2 = bkm.widgets.Panel(child = Gantt_CPS,     title = 'CPS')
tab3 = bkm.widgets.Panel(child = EKG_MAJCOM,    title = 'EKG LOE')
tab4 = bkm.widgets.Panel(child = stacked_areas, title = 'Stacked Area LOE')

# setting the width here gives enough space to put all four tabs on one line
tabs_events = bkm.widgets.Tabs(tabs = [tab1, tab2, tab3, tab4], width = 1000)

# combine widgets and widget_tips into the same column
user_inputs = bkl.column([inputs, tips])

# add eveything into the final product with the desired row/column layout
final_visualization = bkl.layout([[desc],
                                  bkl.row(children = [user_inputs, 
                                         bkl.column(children = [Gantt_Unit,
                                                                tabs_events]),
                                         bkl.column(children = [update_dwell,
                                                               data_table])])])

# prep output file for testing (produces non-interactive html) This generates
# an html file that can be opened without the need for "cl> bokeh serve"
#bkp.output_file('MEC_test.html', title='MEC Test Page')
#bkp.show(final_visualization)


# add figure to curdoc for interactive display by bokeh server
bkp.curdoc().add_root(final_visualization)
bkp.curdoc().title = "Master Exercise Calendar"

##############################################################################
