'''
##############################################################################
#
# FILE: CPS_JTIMS_Join_Dummy_data_elements.py
#
#
# DESCRIPTION: join of two dataframes. Each is dummy data built to match tiny 
#              extracts from JTIMS and CPS (not all fields)
#              (inputs built by Generate_dummy_data.py)
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20171120     James Stockton     Initial coding, minimal modification to 
#                                 existing code
# 20171120     James Stockton     added fields (as in other code)
# 20171220     James Stockton     adjusted color-coding by event name
# 20180123     James Stockton     tidy up, add more comments
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

from os.path import dirname, realpath
import pandas as pd
#from pandas import ExcelFile
           
### !!! Save paths (comment/uncomment) as needed for tarball upload to AWS !!!

# Hardcoded data path allows Spyder to run (helpful during development)
# development machine, data path
#dirpath = "/home/stocktonjc/Coding/A3_CDO_Master_Exercise_Calendar/"
#datapath = dirpath + "data/dummy_data_generation/"
# AWS server, data path
#datapath = "/home/stocktonjc/A3_CDO_Master_Exercise_Calendar/data/"
        
# Dynamically retrieve directory and build data path (used on server or 
# on dev. machine when testing "cl> bokeh serve")
my_directory = dirname(realpath(__file__))
datapath = my_directory + "/"           

# read timestamps from input dummy_data files and manually change as needed
timestamp = "20180116_1549"
datafile_CPS = timestamp + "_Dummy_CPS_Data.csv"
datafile_JTIMS = timestamp + "_Dummy_JTIMS_Data.csv"

# define the output filename
outputFilename = "Unified_Dummy_data_CPS_JTIMS_sample.csv"

##############################################################################

#%%

##############################################################################
# Read in the data and manipulate it into shape
##############################################################################


# read in CPS dummy data
CPS_working_data = pd.read_csv(datapath + datafile_CPS)

# read in JTIMS dummy data
JTIMS_working_data = pd.read_csv(datapath + datafile_JTIMS) 


# cast the Start and End columns to datetime objects
CPS_working_data['Start'] = pd.to_datetime(CPS_working_data['Start'])
CPS_working_data['End'] = pd.to_datetime(CPS_working_data['End'])

JTIMS_working_data['Start Date'] = pd.to_datetime(
                                              JTIMS_working_data['Start Date'])
JTIMS_working_data['End Date'] = pd.to_datetime(JTIMS_working_data['End Date'])


# JTIMS Events stored as a single column. Combine the 2 cols in CPS to 1
CPS_working_data['Events'] = CPS_working_data['Event'] + \
                             " " + \
                             CPS_working_data['Event #']

CPS_working_data['Events_no_spaces'] = CPS_working_data['Events']\
                                                       .str\
                                                       .replace(" ", "")

JTIMS_working_data['Events_no_spaces'] = JTIMS_working_data['Events']\
                                                           .str\
                                                           .replace(" ", "")

CPS_working_data.columns = CPS_working_data.columns.str.cat(
                                others = ["CPS"]*len(CPS_working_data.columns),
                                sep = "_")

JTIMS_working_data.columns = JTIMS_working_data.columns.str.cat(
                            others = ["JTIMS"]*len(JTIMS_working_data.columns),
                            sep = "_")

JTIMS_working_data['Event_Name_JTIMS'] = \
                                    JTIMS_working_data['Events_JTIMS'].str[:-6]

CPS_working_data['Event_Name_CPS'] = CPS_working_data['Events_CPS'].str[:-6]

JTIMS_working_data['Event_Num_JTIMS'] = \
                                    JTIMS_working_data['Events_JTIMS'].str[-5:]

# replace spaces with underscores and octothorpes with 'Num'
CPS_working_data.columns = CPS_working_data.columns.str.replace(" ", "_")
JTIMS_working_data.columns = JTIMS_working_data.columns.str.replace(" ", "_")
CPS_working_data.columns = CPS_working_data.columns.str.replace("#", "Num")
JTIMS_working_data.columns = JTIMS_working_data.columns.str.replace("#", "Num")

                                                                   
# create a string label from the datetime object
JTIMS_working_data['str_Start_Date_JTIMS'] = \
       [x.strftime("%Y-%m-%d") for x in JTIMS_working_data['Start_Date_JTIMS']]
JTIMS_working_data['str_End_Date_JTIMS'] = \
         [x.strftime("%Y-%m-%d") for x in JTIMS_working_data['End_Date_JTIMS']]

CPS_working_data['str_Start_Date_CPS'] = \
                [x.strftime("%Y-%m-%d") for x in CPS_working_data['Start_CPS']]
CPS_working_data['str_End_Date_CPS'] = \
                  [x.strftime("%Y-%m-%d") for x in CPS_working_data['End_CPS']]

# Gather unique event names
unique_event_name_list_JTIMS = sorted(JTIMS_working_data['Event_Name_JTIMS']
                                      .dropna().unique().tolist())

unique_event_name_list_CPS = sorted(CPS_working_data['Event_CPS']
                                    .dropna().unique().tolist())

unique_squadron_name_list_CPS = sorted(CPS_working_data['Sqdn_CPS']
                                       .dropna().unique().tolist())

unique_wing_name_list_CPS = sorted(CPS_working_data['Wing_CPS']
                                   .dropna().unique().tolist())


# given an event name, determine where that name is in the unique name list
def JTIMS_y_position_mapper(string):
    return int(unique_event_name_list_JTIMS.index(string))

# build the top/bottom of the eventual event glyph based on it's list position
JTIMS_working_data['plot_top_JTIMS'] = 0.75 + \
            JTIMS_working_data['Event_Name_JTIMS'].map(JTIMS_y_position_mapper)

JTIMS_working_data['plot_bottom_JTIMS'] = 0.25 + \
            JTIMS_working_data['Event_Name_JTIMS'].map(JTIMS_y_position_mapper)

# Ditto for CPS
def CPS_y_position_mapper(string):
    return int(unique_event_name_list_CPS.index(string))

CPS_working_data['plot_top_CPS'] = 0.75 + \
                       CPS_working_data['Event_CPS'].map(CPS_y_position_mapper)

CPS_working_data['plot_bottom_CPS'] = 0.25 + \
                       CPS_working_data['Event_CPS'].map(CPS_y_position_mapper)

# Ditto for Squadrons
def Squadron_y_position_mapper(string):
    return int(unique_squadron_name_list_CPS.index(string))

CPS_working_data['plot_top_Squadron'] = 0.75 + \
                   CPS_working_data['Sqdn_CPS'].map(Squadron_y_position_mapper)

CPS_working_data['plot_bottom_Squadron'] = 0.25 + \
                   CPS_working_data['Sqdn_CPS'].map(Squadron_y_position_mapper)


# Ditto for Wings
def Wing_y_position_mapper(string):
    return int(unique_wing_name_list_CPS.index(string))

CPS_working_data['plot_top_Wing'] = 0.75 + \
                   CPS_working_data['Wing_CPS'].map(Wing_y_position_mapper)

CPS_working_data['plot_bottom_Wing'] = 0.25 + \
                   CPS_working_data['Wing_CPS'].map(Wing_y_position_mapper)

# These two fields were built to allow each event glyph to show the fraction
# of the squadron involved. NOT CURRENTLY USED AS OF 20180103
CPS_working_data['plot_top_Qty'] = (0.25 + \
                   CPS_working_data['Wing_CPS'].map(Wing_y_position_mapper)) +\
  (round(CPS_working_data['Qty_CPS'] / CPS_working_data['Qty_max_CPS'] / 2, 2))

CPS_working_data['plot_bottom_Qty'] = 0.25 + \
                   CPS_working_data['Wing_CPS'].map(Wing_y_position_mapper)


working_data = pd.merge(left = JTIMS_working_data,
                        right = CPS_working_data,
                        how = "outer",
                        left_on =JTIMS_working_data['Events_no_spaces_JTIMS'],
                        right_on = CPS_working_data['Events_no_spaces_CPS'])


# build a field to control the color saturation (alpha level) of the plotted 
# glyphs (set two levels to facilitate overplotting)
working_data['fill_mapping_alpha_low'] = 0.4
working_data['fill_mapping_alpha_high'] = 0.8

# build color-coding based on whether the JTIMS event has supporting units
#temp_mask = working_data['Event_CPS'].isnull() 
#for ii in range(len(working_data)):
#  if temp_mask[ii]:
#    working_data['fill_mapping'].iloc[ii] = 0.075 
#  else:
#    working_data['fill_mapping'].iloc[ii] = 0.9


# build a field to control the color coding by event name of the plotted glyphs
working_data['event_color'] = None
color_mask = working_data['Event_Name_CPS'].isnull()
for ii in range(len(working_data)):
  if color_mask[ii]:
    working_data['event_color'].iloc[ii] = working_data['Event_Name_JTIMS']\
                                                       .iloc[ii]
  else:
    working_data['event_color'].iloc[ii] = working_data['Event_Name_CPS']\
                                                       .iloc[ii]


##############################################################################

#%%

##############################################################################
# Write out the results
##############################################################################
                                   
# write out the result to the provided output filename
#working_data.to_csv(datapath + outputFilename)  
  
##############################################################################