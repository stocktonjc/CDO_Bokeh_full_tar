'''
##############################################################################
#
# FILE: test.py
#
#
# DESCRIPTION: syntax testing for mutil-index excel/csv input and output
#
# SOFTWARE HISTORY:
# 
# Date         Name               Comment
# 20180206     James Stockton     Initial coding
#
##############################################################################
'''

#%%

##############################################################################
# define data paths, import required packages
##############################################################################

from os.path import dirname, realpath
import pandas as pd
#from pandas import ExcelFile
           
dirpath = "/home/stocktonjc/Coding/A3_CDO_Master_Exercise_Calendar/"
datapath = dirpath + "data/"

#datafile_JTIMS = "JTIMS_extract_single_record_20180205.xlsx"
datafile_JTIMS = "JTIMS_extract_single_record_20180205.csv"

##############################################################################

#%%

##############################################################################
# Read in the data and manipulate it into shape
##############################################################################

raw_input_format = pd.read_csv(datapath + datafile_JTIMS,
                               header  = None)

test = pd.read_csv(datapath + datafile_JTIMS,
                   header =  None)

# fill forward to complete headers on level zero
test.iloc[0] = test.iloc[0].fillna(method = 'ffill')
# fill first entry of zero-th level header
test.iloc[0] = test.iloc[0].fillna("Primary")


new_index = test.iloc[0] + "_" + test.iloc[1]

test.columns = new_index
test = test.drop([0,1])


# read in JTIMS data
#JTIMS_working_data = pd.read_excel(io = datapath + datafile_JTIMS,
#                                   header = [1]) 